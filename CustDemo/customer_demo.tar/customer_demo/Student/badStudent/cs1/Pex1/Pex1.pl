#!/usr/bin/perl
# password generator client (PROTOTYPE)
# Peter Walsh csci 265

$| = 1;

use warnings;
use strict;


use IO::Socket;


my @command;
@command = @ARGV;

my $numofARG=$#command;

my $length=8;
my $type="num";




for(my $i=0;$i<=$numofARG;$i++){
   if($command[$i] eq "-v"){

      print "version 0.9\n";


   }elsif($command[$i]eq"-t") {

      if($i<$numofARG){
         if($command[$i+1]eq"num"){

            $type=$command[$i+1];
            $i++;


      
         }elsif($command[$i+1]eq"alphanum"){

            $type=$command[$i+1];
            $i++;



         }else{

         die "Error: Invalid Type of Password\n";

         }
      }else{
         die "Error: Invalid Type of Password\n";
      }
   }elsif($command[$i]eq"-n"){

      if($i<$numofARG){

         if(($command[$i+1])=~(m/[0-9]/)){
            if(($command[$i+1])=~(m/[[a-z]/i)){
               die "Error: Invalid Lenght\n";
            }else{
               $length=$command[$i+1];
               if(defined($length)){
                  if(($length<2)||($length>64)){
                     die "Error: Invalid Length of Password\n";
                  }else{
                   $i++;
                  }
               }else{
                  die "Error: Invalid Length of Password\n";
               }
            }

         }else{

            die "Error: Invalid Length of Password\n";


         }
      }else{
         die "Errors: Invalid Length of Password \n";
      }
   }else{

   die "Errors: Invalid Argument\n";


   }

}# ends arugment token loop

# values to use to connect to real server
# PeerAddr = 192.168.18.21
# PeerPort = 7071


my $sock;

$sock = new IO::Socket::INET (
                              PeerAddr => 'localhost',
                              PeerPort => '7755',
                              Proto => 'tcp'
                             );
die "Error: Unable to Connect To Password Server\n" unless $sock;



print $sock "2:$type:$length\n";


while (1) {
my $pass;
   $pass = <$sock>;
   chop $pass;
   last if $pass eq "CLOSE";
   print "Password is: $pass \n";
}

